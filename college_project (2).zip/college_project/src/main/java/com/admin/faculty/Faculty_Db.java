package com.admin.faculty;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Faculty_Db 
{
	int flag = 0;
	Faculty_Process fp = new Faculty_Process();
	
	@RequestMapping("/addfaculty")
	public ModelAndView ins(HttpServletRequest req,HttpServletResponse res)
	{
		System.out.println("inside faculty ins");
		
		String faculty_Id = req.getParameter("Faculty_Id");
		String faculty_Name = req.getParameter("Faculty_Name");
		String email = req.getParameter("Email");
		String ph_No = req.getParameter("Ph_No");
		String gender = req.getParameter("Gender");
		String password = req.getParameter("Pwd");
		
		System.out.println(faculty_Id+faculty_Name+ph_No+gender+password);
		System.out.println("email :"+email);
		if(flag == 0 )
		{
		fp.insert(faculty_Id,faculty_Name,email,ph_No,gender,password);
		}
		else
		{
			fp.update_faculty(faculty_Id,faculty_Name,email,ph_No,gender,password);
		}
		ModelAndView m=new ModelAndView();
		m.setViewName("facultyRegistration");
		return m;
		
	}
	
	@RequestMapping("/view_faculty")
	public ModelAndView view() 
	{
		System.out.println("in faculty db");
		 List faculty_Details = fp.getfaculty_Details();
		 ModelAndView m=new ModelAndView();
		 m.setViewName("viewFaculty");
		 System.out.println(faculty_Details);
		m.addObject("list",faculty_Details);
		 return m;
	}
	
	@RequestMapping("/delete_faculty")
	public ModelAndView delete_Course(HttpServletRequest req,HttpServletResponse res) 
	{
		String id = req.getParameter("id");
		System.out.println("passed faculty id"+id);
		fp.faculty_Delete(id);
		ModelAndView m=new ModelAndView();
		m.setViewName("facultyRegistration");
		return m;
		
	}
	
	@RequestMapping("/update_faculty")
	public ModelAndView update_student(HttpServletRequest req,HttpServletResponse res)
	{
		String id = req.getParameter("id");
		flag = 1;
		ModelAndView m=new ModelAndView();
		m.setViewName("facultyRegistration");
		m.addObject("id", id);
		m.addObject("flag", flag);
		return m;
	}

}
