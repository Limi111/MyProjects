package com.admin.faculty;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.admin.course.Course;
import com.campus.faculty.Faculty;


public class Faculty_Process 
{
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
	EntityManager em = emf.createEntityManager();
	public void insert(String faculty_Id, String faculty_Name, String email, String ph_No, String gender,
			String password) 

	{
		System.out.println("inside fac process");
		Faculty f = new Faculty();
		
		em.getTransaction().begin();
		
		f.setFaculty_Id(faculty_Id);
		f.setFaculty_Name(faculty_Name);
		f.setEmail(email);
		f.setPh_No(ph_No);
		f.setGender(gender);
		f.setPassword(password);
		
		em.persist(f);
		em.getTransaction().commit();
		
		
		
	}
	public List getfaculty_Details()
	{
		System.out.println("in faculty process details");
		Query query = em.createQuery("Select f from Faculty f");
		 List<Faculty> list = query.getResultList();
		 return list; 
		
	}
	
	public void faculty_Delete(String id) 
	{
		System.out.println("in faculty process delete");
		em.getTransaction().begin();
		Faculty f = em.find(Faculty.class, id);
		em.remove(f);
		em.getTransaction().commit();
		System.out.println("row deleted");
	}
	public void update_faculty(String faculty_Id, String faculty_Name, String email, String ph_No, String gender,
			String password)
	{
		System.out.println("in update process");
		  
		  em.getTransaction().begin();
		  Faculty f = em.find(Faculty.class, faculty_Id);
		  f.setFaculty_Name(faculty_Name);
		  f.setEmail(email);
		  f.setPh_No(ph_No);
		  f.setGender(gender);
		  f.setPassword(password);
		  em.persist(f);
		  System.out.println("updation complete");
		  em.getTransaction().commit();
		
	}
		
	
	

}
