package com.admin.subject;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="subject")
public class Subject
{
	@Id
private String Sub_Id;
private String Sub_Name;
private String Course_Id;
private int Sem;
public String getSub_Id() {
	return Sub_Id;
}
public void setSub_Id(String sub_Id) {
	Sub_Id = sub_Id;
}
public String getSub_Name() {
	return Sub_Name;
}
public void setSub_Name(String sub_Name) {
	Sub_Name = sub_Name;
}
public String getCourse_Id() {
	return Course_Id;
}
public void setCourse_Id(String course_Id) {
	Course_Id = course_Id;
}
public int getSem() {
	return Sem;
}
public void setSem(int sem) {
	Sem = sem;
}

}
