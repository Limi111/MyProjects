package com.admin.subject;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Subject_Db 
{
	int flag = 0;
	Subject_Process sp = new Subject_Process();
	
	@RequestMapping("/addsubject")
	public ModelAndView ins(HttpServletRequest req,HttpServletResponse res)
	{
		System.out.println("inside subject ins");
		
		String sub_Id = req.getParameter("Sub_Id");
		String sub_Name = req.getParameter("Sub_Name");
		String course_Id = req.getParameter("Course_Id");
		int sem = Integer.parseInt(req.getParameter("Sem"));
		
		System.out.println(sub_Id+sub_Name+course_Id+sem);
		if(flag == 0)
		{
		sp.insert(sub_Id,sub_Name,course_Id,sem);
		}
		else
		{
			sp.subject_Update(sub_Id,sub_Name,course_Id,sem);
		}
		ModelAndView m=new ModelAndView();
		m.setViewName("subjectRegistration");
		return m;
		
	}
	
	@RequestMapping("/view_subject")
	public ModelAndView view() 
	{
		System.out.println("in subject db");
		 List subject_Details = sp.getsubject_Details();
		 ModelAndView m=new ModelAndView();
		 m.setViewName("viewSubject");
		m.addObject("list",subject_Details);
		 return m;
	}
	
	@RequestMapping("/delete_subject")
	public ModelAndView delete_subject(HttpServletRequest req,HttpServletResponse res)
	{
		String id = req.getParameter("id");
		
		sp.subject_Delete(id);
		ModelAndView m=new ModelAndView();
		m.setViewName("subjectRegistration");
		return m;
	}
	
	@RequestMapping("/update_subject")
	public ModelAndView update_student(HttpServletRequest req,HttpServletResponse res)
	{
		String id = req.getParameter("id");
		flag = 1;
		ModelAndView m=new ModelAndView();
		m.setViewName("subjectRegistration");
		m.addObject("id", id);
		m.addObject("flag", flag);
		return m;
	}

}
