package com.admin.subject;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;




public class Subject_Process 
{
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
	EntityManager em = emf.createEntityManager();
	public void insert(String sub_Id,String sub_Name,String course_Id,int sem) 
	{
		System.out.println("inside sub process");
		Subject s = new Subject();
		
		em.getTransaction().begin();
		s.setSub_Id(sub_Id);
		s.setSub_Name(sub_Name);
		s.setCourse_Id(course_Id);
		s.setSem(sem);
		
		
		em.persist(s);
		em.getTransaction().commit();
		
		
	}
	public List getsubject_Details()
	{
		System.out.println("in course process");
		Query query = em.createQuery("Select sub from Subject sub");
		 @SuppressWarnings("unchecked") List<Subject> list = query.getResultList();
		 return list; 
		
	}
	
	public void subject_Delete(String id) 
	{
		System.out.println("in subject process delete");
		em.getTransaction().begin();
		Subject s = em.find(Subject.class, id);
		em.remove(s);
		em.getTransaction().commit();
		System.out.println("row deleted");
	}
	public void subject_Update(String sub_Id, String sub_Name, String course_Id, int sem) 
	{
		System.out.println("in update process");
		em.getTransaction().begin();
		Subject s = em.find(Subject.class, sub_Id); 
		s.setSub_Name(sub_Name);
		s.setCourse_Id(course_Id);
		s.setSem(sem);
		em.persist(s);
		System.out.println("updation complete");
		em.getTransaction().commit();
	}
	
	

}
