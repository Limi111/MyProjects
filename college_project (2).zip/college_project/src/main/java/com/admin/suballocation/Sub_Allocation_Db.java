package com.admin.suballocation;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Sub_Allocation_Db 
{
	int flag = 0;
	Sub_Allocation_Process sp = new Sub_Allocation_Process();
	ModelAndView m=new ModelAndView();
	
	@RequestMapping("/addfac_sub")
	public ModelAndView ins(HttpServletRequest req,HttpServletResponse res)
	{
		System.out.println("inside sub allocation insert");
		
		String faculty_sub_allocation_Id = req.getParameter("Faculty_sub_allocation_Id");
		String sub_Id = req.getParameter("Sub_Id");
		String faculty_Id = req.getParameter("Faculty_Id");
		
		System.out.println(faculty_sub_allocation_Id + sub_Id + faculty_Id);
		
		if(flag == 0)
		{
		sp.insert(faculty_sub_allocation_Id,sub_Id,faculty_Id);
		}
		else
		{
			sp.facSub_Update(faculty_sub_allocation_Id,sub_Id,faculty_Id);
		}
		m.setViewName("facultySubRegistration");
		return m;
		
	}
	
	@RequestMapping("/view_sub_allocation")
	public ModelAndView view() 
	{
		System.out.println("in sub allocation db");
		 List sub_allocation = sp.getsub_allocation();
		 m.setViewName("viewsuballocation");
		m.addObject("list",sub_allocation);
		 return m;
	}
	
	@RequestMapping("/delete_sub_alloc")
	public ModelAndView delete_SubAlloc(HttpServletRequest req,HttpServletResponse res) 
	{
		String id = req.getParameter("id");
		System.out.println("passed sub allocation id"+id);
		sp.facSub_Delete(id);
		ModelAndView m=new ModelAndView();
		m.setViewName("facultySubRegistration");
		return m;
		
	}
	@RequestMapping("/update_subAlloc")
	public ModelAndView update_subAlloc(HttpServletRequest req,HttpServletResponse res)
	{
		String id = req.getParameter("id");
		flag = 1;
		ModelAndView m=new ModelAndView();
		m.setViewName("facultySubRegistration");
		m.addObject("id", id);
		m.addObject("flag", flag);
		return m;
	}

}
