package com.admin.suballocation;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="faculty_subject")
public class Faculty_subject 
{
	@Id
	private String Faculty_sub_allocation_Id;
	private String Sub_Id;
	private String Faculty_Id;
	
	public String getFaculty_sub_allocation_Id() {
		return Faculty_sub_allocation_Id;
	}
	public void setFaculty_sub_allocation_Id(String faculty_sub_allocation_Id) {
		Faculty_sub_allocation_Id = faculty_sub_allocation_Id;
	}
	public String getSub_Id() {
		return Sub_Id;
	}
	public void setSub_Id(String sub_Id) {
		Sub_Id = sub_Id;
	}
	public String getFaculty_Id() {
		return Faculty_Id;
	}
	public void setFaculty_Id(String faculty_Id) {
		Faculty_Id = faculty_Id;
	}
	@Override
	public String toString() {
		return "faculty_subject [Faculty_sub_allocation_Id=" + Faculty_sub_allocation_Id + ", Sub_Id=" + Sub_Id
				+ ", Faculty_Id=" + Faculty_Id + "]";
	}
	
	
}
