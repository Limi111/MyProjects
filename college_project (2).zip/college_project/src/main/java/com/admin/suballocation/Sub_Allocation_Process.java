package com.admin.suballocation;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.admin.course.Course;


public class Sub_Allocation_Process 
{
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
	EntityManager em = emf.createEntityManager();
	
	public void insert(String faculty_sub_allocation_Id,String sub_Id,String faculty_Id) 
	{
		Faculty_subject fs = new Faculty_subject();
		
		em.getTransaction().begin();
		
		fs.setFaculty_sub_allocation_Id(faculty_sub_allocation_Id);
		fs.setFaculty_Id(faculty_Id);
		fs.setSub_Id(sub_Id);
		
		em.persist(fs);
		em.getTransaction().commit();
		
		
	}
	public List getsub_allocation() 
	{
		System.out.println("in su allocation process");
		Query query = em.createQuery("Select fs from Faculty_subject fs");
		 @SuppressWarnings("unchecked") List<Faculty_subject> list = query.getResultList();
		 return list; 
		
	}
	public void facSub_Delete(String id) 
	{
		System.out.println("in facSub allocation process delete");
		em.getTransaction().begin();
		Faculty_subject fs = em.find(Faculty_subject.class, id);
		em.remove(fs);
		em.getTransaction().commit();
		System.out.println("row deleted");
	}
	public void facSub_Update(String faculty_sub_allocation_Id, String sub_Id, String faculty_Id) 
	{
		    System.out.println("in update process");
		    em.getTransaction().begin();
			Faculty_subject fs = em.find(Faculty_subject.class, faculty_sub_allocation_Id);
			fs.setFaculty_Id(faculty_Id);
			fs.setSub_Id(sub_Id);
			em.persist(fs);
		    System.out.println("updation complete");
		    em.getTransaction().commit();
		
	}
	
		
	
	

}
