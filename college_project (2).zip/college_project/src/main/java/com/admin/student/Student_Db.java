package com.admin.student;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.campus.configure.Student;

@Controller
public class Student_Db 
{
	Student_Process sp = new Student_Process();
	int flag=0;
	
	@RequestMapping("/addstudent")
	public ModelAndView ins(HttpServletRequest req,HttpServletResponse res)
	{
		String admission_No = req.getParameter("Admno");
		String name = req.getParameter("Name");
		String password = req.getParameter("Pwd");
		if(flag == 0)
		{
		sp.insert(admission_No,name,password);
		}
		else
		{
			flag = 0;
			System.out.println("in update db");
			System.out.println("passing value  :");
			System.out.println(admission_No+name+password);
			sp.student_Update(admission_No,name,password);
			System.out.println("calling view");
			}
		ModelAndView m=new ModelAndView();
		m.setViewName("studentRegistration");
		return m;
		
	}
	
	@RequestMapping("/view_student")
	public ModelAndView view(HttpServletRequest req,HttpServletResponse res) 
	{
		 List student_Details = sp.getstudent_Details();
		 ModelAndView m=new ModelAndView();
		 //res.setIntHeader("Refresh", 5);
		 m.setViewName("viewStudent");
		m.addObject("list",student_Details);
		 return m;
	}
	
	@RequestMapping("/delete_student")
	public ModelAndView delete_student(HttpServletRequest req,HttpServletResponse res)
	{
		String id = req.getParameter("id");
		sp.student_Delete(id);
		ModelAndView m=new ModelAndView();
		m.setViewName("studentRegistration");
		return m;
	}
	
	@RequestMapping("/update_student")
	public ModelAndView update_student(HttpServletRequest req,HttpServletResponse res)
	{
		String id = req.getParameter("id");
		flag = 1;
		ModelAndView m=new ModelAndView();
		m.setViewName("studentRegistration");
		m.addObject("id", id);
		m.addObject("flag", flag);
		return m;
	}


}
