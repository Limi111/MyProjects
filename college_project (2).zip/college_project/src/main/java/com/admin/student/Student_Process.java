package com.admin.student;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.web.servlet.ModelAndView;

import com.campus.configure.Student;

public class Student_Process 
{
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
	EntityManager em = emf.createEntityManager();
	
	public void insert(String admission_No,String name,String password)
	{
		Student s = new Student();
		em.getTransaction().begin();
		System.out.println(admission_No);
		s.setAdmission_No(admission_No);
		s.setName(name);
		s.setPassword(password);
		
		em.persist(s);
		em.getTransaction().commit();
	}

	public List getstudent_Details() 
	{
	    
		 Query query = em.createQuery("Select stu from Student stu");
		 List<Student> list = query.getResultList();
		 
		 System.out.println("result list" + list);
		 return list; 
		
	}

	public void student_Delete(String id) 
	{
		System.out.println("in student process update");
		em.getTransaction().begin();
		Student s=new Student();
		 s = em.find(Student.class, id);
		em.remove(s);
		em.getTransaction().commit();
		System.out.println("row deleted");
	}

	public void student_Update(String admission_No,String name,String password) 
	{
		  System.out.println("in update process");
		  	em.getTransaction().begin();
		  	Student s=new Student();
			 s = em.find(Student.class,admission_No);
			s.setName(name);
			s.setPassword(password);
			em.persist(s);
		  System.out.println("updation complete");
		  em.getTransaction().commit();
		 
		
	}

	
	

}
