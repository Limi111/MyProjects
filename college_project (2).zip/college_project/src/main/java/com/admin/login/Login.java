package com.admin.login;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

@Controller

public class Login {
	@RequestMapping(path = "/admin_login", method = RequestMethod.POST)
	public ModelAndView studentlogin(HttpServletRequest req) {

		System.out.println("inside studentlogin");

		String userid = req.getParameter("username");
		String pwd = req.getParameter("password");

		System.out.println("user_id   " + userid + "\n" + "password    " + pwd);

		ModelAndView mv;
		if (userid.equals("Admin") && pwd.equals("admin")) {
			System.out.println("admin");
			mv = new ModelAndView("courseRegistration");
		} else {
			mv = new ModelAndView("adminLogin");
			mv.addObject("message", "Invalid Login!!");
		}

		return mv;

	}

}
