package com.admin.parent;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.web.servlet.ModelAndView;

import com.admin.course.Course;
import com.campus.parent.Parent;

public class Parent_Process 
{
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
	EntityManager em = emf.createEntityManager();
	
	public void insert(int parent_Id,String parent_Name,String address,String ph_No,String admission_No,String pwd)
	{
		System.out.println("in parent Insert");
		Parent p = new Parent();
		System.out.println(parent_Id+" "+parent_Name+""+address+""+ph_No+admission_No);
		em.getTransaction().begin();
		
		p.setParent_Id(parent_Id);
		p.setParent_Name(parent_Name);
		p.setAddress(address);
		p.setPh_No(ph_No);
		p.setAdmission_No(admission_No);
		p.setPassword(pwd);
		em.persist(p);
		em.getTransaction().commit();
	}

	public List getparent_Details() 
	{
	    
		 Query query = em.createQuery("Select p from Parent p");
		 List<Parent> list = query.getResultList();
		 
		 System.out.println("result list" + list);
		 return list; 
		
	}

	public void parent_Delete(int id) 
	{
		System.out.println("in parent process delete"+"\n"+"id"+id);
		em.getTransaction().begin();
		Parent p = em.find(Parent.class, id);
		em.remove(p);
		em.getTransaction().commit();
		System.out.println("row deleted");
	}

	public void parent_Update(int parent_Id, String parent_Name, String address, String ph_No, String admission_No,String pwd) 
	{
		  System.out.println("in update process");
		  em.getTransaction().begin();
		  Parent p = em.find(Parent.class, parent_Id);
		  p.setParent_Name(parent_Name);
		  p.setAddress(address);
		  p.setPh_No(ph_No);
		  p.setAdmission_No(admission_No);
		  p.setPassword(pwd);
		  em.persist(p);
		  System.out.println("updation complete");
		  em.getTransaction().commit();
		
	}

	

}
