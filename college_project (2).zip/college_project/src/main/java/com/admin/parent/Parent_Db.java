package com.admin.parent;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Parent_Db 
{
	int flag = 0;
	Parent_Process pp = new Parent_Process();
	
	@RequestMapping("/addparent")
	public ModelAndView ins(HttpServletRequest req)
	{
		System.out.println("in parent DB");
		int parent_Id = Integer.parseInt(req.getParameter("Parent_Id"));
		String parent_Name = req.getParameter("Parent_Name");
		String address = req.getParameter("Address");
		String ph_No = req.getParameter("Ph_No");
		String admission_No = req.getParameter("Admno");
		String pwd=req.getParameter("Pwd");
		
		if(flag == 0)
		{
		pp.insert(parent_Id,parent_Name,address,ph_No,admission_No,pwd);
		}
		else
		{
			pp.parent_Update(parent_Id,parent_Name,address,ph_No,admission_No,pwd);
		}
		
		ModelAndView m=new ModelAndView();
		m.setViewName("parentRegistration");
		return m;
		
	}
	
	@RequestMapping("/view_parent")
	public ModelAndView view() 
	{
		 List parent_Details = pp.getparent_Details();
		 
		 ModelAndView m=new ModelAndView();
		 m.setViewName("viewParent");
		m.addObject("list",parent_Details);
		 return m;
	}
	
	@RequestMapping("/delete_parent")
	public ModelAndView delete_Parent(HttpServletRequest req,HttpServletResponse res) 
	{
		int id = Integer.parseInt(req.getParameter("id"));
		System.out.println("passed parent id"+id);
		pp.parent_Delete(id);
		ModelAndView m=new ModelAndView();
		m.setViewName("parentRegistration");
		return m;
		
	}
	
	@RequestMapping("/update_parent")
	public ModelAndView update_parent(HttpServletRequest req,HttpServletResponse res)
	{
		
		String id = req.getParameter("id");
		System.out.println("passed id" + id);
		flag = 1;
		ModelAndView m=new ModelAndView();
		m.setViewName("parentRegistration");
		m.addObject("id", id);
		m.addObject("flag", flag);
		return m;
	}
	


}
