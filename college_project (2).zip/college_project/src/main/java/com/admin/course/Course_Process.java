package com.admin.course;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;


public class Course_Process 
{
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
	EntityManager em = emf.createEntityManager();
	public void insert(String course_Id, String course_Name, int duration, int no_Of_Sem) 
	{
		Course c = new Course();
		
		em.getTransaction().begin();
		
		c.setCourse_Id(course_Id);
		c.setCourse_Name(course_Name);
		c.setDuration(duration);
		c.setNo_Of_Sem(no_Of_Sem);
		
		em.persist(c);
		em.getTransaction().commit();
		
		
	}
	public List getcourse_Details()
	{
		System.out.println("in course process");
		Query query = em.createQuery("Select c from Course c");
		List<Course> list = query.getResultList();
		 return list; 
		
	}
	
	public void course_Delete(String id)  
	{
		System.out.println("in course process delete");
		em.getTransaction().begin();
		Course c = em.find(Course.class, id);
		em.remove(c);
		em.getTransaction().commit();
		System.out.println("row deleted");
		
	}
	public void course_update(String course_Id,String course_Name,int duration,int no_Of_Sem) 
	{
		System.out.println("in update process");
		System.out.println("in course process delete");
		em.getTransaction().begin();
		Course c = em.find(Course.class, course_Id);
		c.setCourse_Name(course_Name);
		c.setDuration(duration);
		c.setNo_Of_Sem(no_Of_Sem);
		
		    em.persist(c);
		System.out.println("updation complete");
	    em.getTransaction().commit();
		
		
	}

	
	

}
