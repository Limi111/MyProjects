package com.admin.course;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Course_Db 
{
	Course_Process cp = new Course_Process();
	int flag=0;
	
	@RequestMapping("/addcourse")
	public ModelAndView ins(HttpServletRequest req,HttpServletResponse res)
	{
		String course_Id = req.getParameter("Course_Id");
		String course_Name = req.getParameter("Course_Name");
		int duration = Integer.parseInt(req.getParameter("Duration"));
		int no_Of_Sem = Integer.parseInt(req.getParameter("No_Of_Sem"));
		
		if(flag == 0)
		{
		System.out.println("inside course ins");
		cp.insert(course_Id,course_Name,duration,no_Of_Sem);
		}
		else
		{
			flag = 0;
			System.out.println("in update db");
			cp.course_update(course_Id,course_Name,duration,no_Of_Sem);
			System.out.println("calling view");
		}
		ModelAndView m=new ModelAndView();
		m.setViewName("courseRegistration");
		return m;
		
	}
	
	@RequestMapping("/view_course")
	public ModelAndView view() 
	{
		System.out.println("in course db");
		 List course_Details = cp.getcourse_Details();
		 ModelAndView m=new ModelAndView();
		 m.setViewName("viewCourse");
		m.addObject("list",course_Details);
		 return m;
	}
	
	@RequestMapping("/delete_course")
	public ModelAndView delete_Course(HttpServletRequest req,HttpServletResponse res) 
	{
		String id = req.getParameter("id");
		System.out.println("passed course id"+id);
		cp.course_Delete(id);
		ModelAndView m=new ModelAndView();
		m.setViewName("courseRegistration");
		return m;
		
	}
	
	@RequestMapping("/update_course")
	public ModelAndView update_Course(HttpServletRequest req,HttpServletResponse res) 
	{
		String id = req.getParameter("id");
		flag = 1;
		ModelAndView m=new ModelAndView();
		m.setViewName("courseRegistration");
		m.addObject("id", id);
		m.addObject("flag", flag);
		m.addObject("id", id);
		return m;
	}
		
		
	

}
