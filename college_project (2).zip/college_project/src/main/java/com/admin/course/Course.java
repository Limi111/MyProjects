package com.admin.course;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="course")
public class Course 
{
	@Id
	private String Course_Id;
	private String Course_Name;
	private int Duration;
	private int No_Of_Sem;
	
	public String getCourse_Id() {
		return Course_Id;
	}
	public void setCourse_Id(String course_Id) {
		Course_Id = course_Id;
	}
	public String getCourse_Name() {
		return Course_Name;
	}
	public void setCourse_Name(String course_Name) {
		Course_Name = course_Name;
	}
	public int getDuration() {
		return Duration;
	}
	public void setDuration(int duration) {
		Duration = duration;
	}
	public int getNo_Of_Sem() {
		return No_Of_Sem;
	}
	public void setNo_Of_Sem(int no_Of_Sem) {
		No_Of_Sem = no_Of_Sem;
	}
	@Override
	public String toString() {
		return "course [Course_Id=" + Course_Id + ", Course_Name=" + Course_Name + ", Duration=" + Duration
				+ ", No_Of_Sem=" + No_Of_Sem + "]";
	}
	
	

}
