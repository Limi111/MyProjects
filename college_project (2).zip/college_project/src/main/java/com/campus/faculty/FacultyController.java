package com.campus.faculty;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.campus.configure.Addservice;
import com.campus.configure.Student;
import com.campus.parent.Parent;

@Controller

public class FacultyController {
	FacultyAddService addservice = new FacultyAddService();

	@RequestMapping("/faculty_login")
	public ModelAndView facultyLogin(HttpServletRequest req, HttpServletResponse res) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
		EntityManager em = emf.createEntityManager();
		String user = req.getParameter("username");

		String pass = req.getParameter("password");
		System.out.println("inside faculty login");
		System.out.println(user);
		System.out.println(pass);

		List<Faculty> list = addservice.Login(user, pass);
		ModelAndView m = new ModelAndView();
		if (list.size() > 0) {
			
			m = new ModelAndView("faculty_home");
			m.addObject("fid", user);
			
		} else {
			m = new ModelAndView("faculty_login");
			m.addObject("message", "Invalid Login!!");
		}

		

		return m;

	}

	@RequestMapping("/faculty_update")
	public ModelAndView updateInfo(HttpServletRequest req, HttpServletResponse res) {

		String Faculty_Id = req.getParameter("FacId");
		String Faculty_Name = req.getParameter("Name");
		String Email = req.getParameter("Email");
		String Phone_No = req.getParameter("Ph_No");
		String Gender = req.getParameter("gender");
		String Password = req.getParameter("Password");

		ModelAndView mv = new ModelAndView();
		mv = addservice.update(Faculty_Id, Faculty_Name, Email, Phone_No, Gender, Password);

		return mv;
	}

	@RequestMapping("/editmarks")
	public ModelAndView editMarks(HttpServletRequest req, HttpServletResponse res) {

		String admn_no = req.getParameter("Admission_No");
		String Series_No = req.getParameter("Series_No");
		String sub_id = req.getParameter("Sub_Id");
		int sem = Integer.parseInt(req.getParameter("Sem"));
		int marks = Integer.parseInt(req.getParameter("Marks"));
		System.out.println(marks);
		String Exam_Date = req.getParameter("Exam_Date");
		ModelAndView mv = new ModelAndView();
		mv = addservice.insert(admn_no, Series_No, sub_id, sem, marks, Exam_Date);
		return mv;
	}

}
