package com.campus.faculty;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.campus.configure.Student;
import com.campus.parent.Parent;
import com.campus.parent.Student_Marks;

@Service
public class FacultyAddService {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
	EntityManager em = emf.createEntityManager();

	public List Login(String user, String pass) {
		// TODO Auto-generated method stub
				// TODO Auto-generated method stub
		Faculty f = new Faculty();
		Query query = em.createQuery(
				"SELECT fy.Faculty_Id,fy.Password FROM Faculty fy WHERE fy.Faculty_Id=:user and fy.Password=:pass");
		query.setParameter("user", user);
		query.setParameter("pass", pass);
		List<Faculty> list = query.getResultList();
		System.out.println(list.size());

		return list;

	}

	public ModelAndView update(String faculty_Id, String faculty_Name, String email, String phone_No, String gender,
			String password) {
		// TODO Auto-generated method stub
		
		Faculty f1 = new Faculty();
		em.getTransaction().begin();
		f1=em.find(Faculty.class,faculty_Id );
		f1.setFaculty_Name(faculty_Name);
		f1.setEmail(email);
		f1.setPh_No(phone_No);
		f1.setGender(gender);
		f1.setPassword(password);
		em.persist(f1);
		ModelAndView m = new ModelAndView();
		em.getTransaction().commit();
	
		
			m.setViewName("faculty_home");
			m.addObject("fid", faculty_Id);

	
		return m;
	}

	public ModelAndView insert(String admn_no, String series_No, String sub_id, int sem, int marks, String exam_Date) {
		// TODO Auto-generated method stub
		
		Student_Marks sm = new Student_Marks();
		sm.setAdmission_No(admn_no);
		sm.setSub_Id(sub_id);
		sm.setSem(sem);
		sm.setseries(series_No);
		sm.setMark(marks);
		sm.setExam_Date(exam_Date);
		em.getTransaction().begin();
		em.persist(sm);
		em.getTransaction().commit();
		System.out.println(marks);
		ModelAndView m = new ModelAndView();
		m.setViewName("Enter_Marks");
		return m;
	}


	

}
