package com.campus.faculty;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="faculty")
public class Faculty 
{
	@Id
private String Faculty_Id;
private String Faculty_Name;
private String Email;
private String Ph_No;
private String Gender;
private String Password;


public Faculty() {
	super();
}
public String getFaculty_Id() {
	return Faculty_Id;
}
public void setFaculty_Id(String faculty_Id) {
	Faculty_Id = faculty_Id;
}
public String getFaculty_Name() {
	return Faculty_Name;
}
public void setFaculty_Name(String faculty_Name) {
	Faculty_Name = faculty_Name;
}
public String getEmail() {
	return Email;
}
public void setEmail(String email) {
	Email = email;
}
public String getPh_No() {
	return Ph_No;
}
public void setPh_No(String ph_No) {
	Ph_No = ph_No;
}
public String getGender() {
	return Gender;
}
public void setGender(String gender) {
	Gender = gender;
}
public String getPassword() {
	return Password;
}
public void setPassword(String password) {
	Password = password;
}


}
