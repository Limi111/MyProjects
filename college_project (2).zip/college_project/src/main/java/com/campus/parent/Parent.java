package com.campus.parent;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="parent")
public class Parent 
{
	@Id
private  int Parent_Id;
private String Parent_Name;
private String Address;
private String Ph_No;
private String Admission_No;
private String Password;


public Parent() {
	super();
}
public int getParent_Id() {
	return Parent_Id;
}
public void setParent_Id(int parent_Id) {
	Parent_Id = parent_Id;
}
public String getParent_Name() {
	return Parent_Name;
}
public void setParent_Name(String parent_Name) {
	Parent_Name = parent_Name;
}
public String getAddress() {
	return Address;
}
public void setAddress(String address) {
	Address = address;
}

public String getPh_No() {
	return Ph_No;
}
public void setPh_No(String ph_No) {
	Ph_No = ph_No;
}
public String getAdmission_No() {
	return Admission_No;
}
public void setAdmission_No(String admission_No) {
	Admission_No = admission_No;
}
public String getPassword() {
	return Password;
}
public void setPassword(String password) {
	Password = password;
}



}

