package com.campus.parent;

import java.rmi.ServerException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.campus.configure.Addservice;
import com.campus.configure.Student;

@Controller
public class ParentController {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
	EntityManager em = emf.createEntityManager();
	AddService addservice=new AddService();
	
	
	
	@RequestMapping("/parent_login")
	public ModelAndView studentlogin(HttpServletRequest req, HttpServletResponse res) {
      System.out.println("inside parent cntroller");
		int user = Integer.parseInt(req.getParameter("username"));

		String pass = req.getParameter("password");
     
		ModelAndView m = new ModelAndView();
         List<Parent> list= addservice.getMatch(user,pass);
          
        if(list.size()>0)
		{
			 m=new ModelAndView("parent_home");
			
		}
		else {
			   m = new ModelAndView("parent_login");
			    m.addObject("message", "Invalid Login!!");
		}
			
		return m;

	}
	@RequestMapping("/view_mark")
	public ModelAndView ViewMarks(HttpServletRequest req, HttpServletResponse res) {
		String admn_no = req.getParameter("admission_no");

		int sem = Integer.parseInt(req.getParameter("sem"));
		System.out.println("inside View mark in controller");
		ModelAndView m=addservice.displayStudentMarks(admn_no,sem);
        
		return m;
		
	}
}
