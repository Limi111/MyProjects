package com.campus.parent;

import java.sql.Date;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="student_marks")
public class Student_Marks 
{
	@Id
	@Column(name = "Exam_Id", unique = true)
	@GeneratedValue(strategy=GenerationType.AUTO)
private int Exam_Id;
private String Admission_No;

private String series;
private String Sub_Id;
private int Sem;
private int Mark;
private String Exam_Date;

public Student_Marks() {
	super();
}
public int getExam_Id() {
	return Exam_Id;
}
public void setExam_Id(int exam_Id) {
	Exam_Id = exam_Id;
}
public String getAdmission_No() {
	return Admission_No;
}
public void setAdmission_No(String admission_No) {
	Admission_No = admission_No;
}
public String getseries() {
	return series;
}
public void setseries(String series) {
	this.series = series;
}
public String getSub_Id() {
	return Sub_Id;
}
public void setSub_Id(String sub_Id) {
	Sub_Id = sub_Id;
}
public int getSem() {
	return Sem;
}
public void setSem(int sem) {
	Sem = sem;
}
public int getMark() {
	return Mark;
}
public void setMark(int Mark) {
	this.Mark = Mark;
}
public String getExam_Date() {
	return Exam_Date;
}
public void setExam_Date(String exam_Date) {
	Exam_Date = exam_Date;
}
@Override
public String toString() {
	return "Student_Marks [Admission_No=" + Admission_No + ", series=" + series + ", Sub_Id=" + Sub_Id + ", Sem=" + Sem
			+ ", Mark=" + Mark + ", Exam_Date=" + Exam_Date + "]";
}


}