package com.campus.configure;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="student")
public class Student
{
@Id

private String Admission_No;
private String Name;
private String Dob;
private String Gender;
private String Email;
private String Parent_Name;
private String Parent_Ph_No;
private String Course_Id;
private int Sem;
private int Batch;


public Student() {
	super();
}
@Column(name="Password")
private String Password;



public String getAdmission_No() {
	return Admission_No;
}
public void setAdmission_No(String admission_No) {
	Admission_No = admission_No;
}
public String getName() {
	return Name;
}
public void setName(String name) {
	Name = name;
}

public String getDob() {
	return Dob;
}
public void setDob(String dob) {
	Dob = dob;
}
public String getGender() {
	return Gender;
}
public void setGender(String gender) {
	Gender = gender;
}
public String getEmail() {
	return Email;
}
public void setEmail(String email) {
	Email = email;
}
public String getParent_Name() {
	return Parent_Name;
}
public void setParent_Name(String parent_Name) {
	Parent_Name = parent_Name;
}
public String getParent_Ph_No() {
	return Parent_Ph_No;
}
public void setParent_Ph_No(String parent_Ph_No) {
	Parent_Ph_No = parent_Ph_No;
}
public String getCourse_Id() {
	return Course_Id;
}
public void setCourse_Id(String course_Id) {
	Course_Id = course_Id;
}
public int getSem() {
	return Sem;
}
public void setSem(int sem) {
	Sem = sem;
}
public int getBatch() {
	return Batch;
}
public void setBatch(int batch) {
	Batch = batch;
}
public String getPassword() {
	return Password;
}
public void setPassword(String password) {
	Password = password;
}
@Override
public String toString() {
	return "Student [Admission_No=" + Admission_No + ", Name=" + Name + ", Dob=" + Dob + ", Gender=" + Gender
			+ ", Email=" + Email + ", Parent_Name=" + Parent_Name + ", Parent_Ph_No=" + Parent_Ph_No + ", Course_Id="
			+ Course_Id + ", Sem=" + Sem + ", Batch=" + Batch + ", Password=" + Password + "]";
}




}
