package com.campus.configure;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.campus.faculty.Faculty;
import com.campus.parent.Parent;
import com.campus.parent.Student_Marks;

@Service
public class Addservice {

	EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
	EntityManager em = emf.createEntityManager();
     ModelAndView m;
	public ModelAndView login(String user, String pass) {
		// TODO Auto-generated method stub
		Query query = em.createQuery(
				"SELECT s.Admission_No,s.Password FROM Student s WHERE s.Admission_No = :user and s.Password=:pass");
		query.setParameter("user", user);
		query.setParameter("pass", pass);
		List<Student> list = query.getResultList();
		if (list.size() > 0) {
			System.out.println("fgyuy");
			m = new ModelAndView("student_home");
			m.addObject("admission_no", user);
		} else {
			m = new ModelAndView("student_login");
			m.addObject("message", "Invalid Login!!");
		}
		
		return m;
	}


	public void update(String admission_no, String name, String Dob, String gender, String email,
			String parent_name, String parent_contact_no, String course_id, int sem, int batch, String password) {
		// TODO Auto-generated method stub

		
		em.getTransaction().begin();

		Student s=em.find(Student.class,admission_no );
        s.setBatch(batch);
        s.setName(name);
        s.setGender(gender);
        s.setEmail(email);
        s.setParent_Name(parent_name);
        s.setParent_Ph_No(parent_contact_no);
        s.setCourse_Id(course_id);
        s.setSem(sem);
      s.setPassword(password);
      s.setDob(Dob);
      em.persist(s);
      em.getTransaction().commit();
		
	}

	public ModelAndView displayStudentMarks(String admn_no, int sem) {

		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
		EntityManager em = emf.createEntityManager();
		System.out.println(admn_no);
		Double sum1 = 0.0;
		Double sum2 = 0.0;
		double percentage1 = 0.0;
		double percentage2 = 0.0;
		Query query1 = em.createQuery(
	"SELECT sm FROM Student_Marks sm WHERE sm.Admission_No=:admn_no and sm.Sem=:sem and sm.series=:series");
		query1.setParameter("admn_no", admn_no);
		query1.setParameter("sem", sem);
		query1.setParameter("series", "series1");
		Query query2 = em.createQuery(
		"SELECT sm FROM Student_Marks sm WHERE sm.Admission_No=:admn_no and sm.Sem=:sem and sm.series=:series");
		query2.setParameter("admn_no", admn_no);
		query2.setParameter("sem", sem);
		query2.setParameter("series", "series2");
		List<Student_Marks> list1 = query1.getResultList();
		int result1 = list1.size();
		int max_marks1 = result1 * 50;
		for (Student_Marks student : list1) {
			sum1 = sum1 + student.getMark();
			System.out.println(student.getExam_Id());
			System.out.println(student.getAdmission_No());
			System.out.println(student.getseries());
			System.out.println(student.getSem());
			System.out.println(student.getSub_Id());
			System.out.println(student.getMark());
			System.out.println(student.getExam_Date());

		}
		percentage1 = ((sum1 / max_marks1) * 100);
		System.out.println(sum1 + " " + percentage1);

		List<Student_Marks> list2 = query2.getResultList();

		int result2 = list2.size();
		int max_marks2 = result2 * 50;
		for (Student_Marks student : list2) {
			sum2 = sum2 + student.getMark();
			System.out.println(student.getExam_Id());
			System.out.println(student.getAdmission_No());
			System.out.println(student.getseries());
			System.out.println(student.getSem());
			System.out.println(student.getSub_Id());
			System.out.println(student.getMark());
			System.out.println(student.getExam_Date());

		}
		percentage2 = ((sum2 / max_marks2) * 100);
		System.out.println(sum2 + " " + percentage2);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("view");
		mv.addObject("studentlist1", list1);
		mv.addObject("studentlist2", list2);
		mv.addObject("sum1", sum1);
		mv.addObject("sum2", sum2);
		mv.addObject("percentage1", percentage1);
		mv.addObject("percentage2", percentage2);
		return mv;

	}


	
	/*
	 * public List<Student> viewupdate(String admission_no) { // TODO Query
	 * query=em.
	 * createQuery("select stu from Student stu where stu.Admission_No=:admission_no"
	 * ); query.setParameter("admission_no", admission_no);
	 * List<Student>list=query.getResultList(); System.out.println(list);
	 * System.out.println(admission_no); return list;
	 * 
	 * }
	 */
	 


}
