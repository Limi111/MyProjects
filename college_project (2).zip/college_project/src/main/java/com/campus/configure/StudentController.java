package com.campus.configure;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.sql.*;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.campus.faculty.Faculty;

@Controller

public class StudentController {

	@Autowired
	Addservice addservice;
	ModelAndView m;

	@RequestMapping("/login")
	public ModelAndView studentlogin(HttpServletRequest req, HttpServletResponse res) {

		String user = req.getParameter("username");

		String pass = req.getParameter("password");
		m = addservice.login(user, pass);
		System.out.println("inside student login");
		return m;

	}

	@RequestMapping("/edit")
	public ModelAndView updateInfo(HttpServletRequest req, HttpServletResponse res) {

		String admission_no = req.getParameter("admn_no");
		System.out.println(admission_no);
		String name = req.getParameter("Name");

		String Dob = req.getParameter("Dob");

		String gender = req.getParameter("gender");
		String email = req.getParameter("Email");
		String parent_name = req.getParameter("Parent_Name");
		String parent_contact_no = req.getParameter("Parent_contact_no");
		String course_id = req.getParameter("Course_Id");
		int sem = Integer.parseInt(req.getParameter("Sem"));
		int batch = Integer.parseInt(req.getParameter("Batch"));
		String password = req.getParameter("Pwd");

		addservice.update(admission_no, name, Dob, gender, email, parent_name, parent_contact_no, course_id, sem, batch,
				password);
		/*
		 * List<Student> list = addservice.viewupdate(admission_no); Student stu = new
		 * Student(); for (Student li : list) { stu = li; }
		 */
		m.setViewName("student_home");
		m.addObject("message","updated successfully" );

		return m;

	}

	@RequestMapping("/view_mark1")
	public ModelAndView ViewMarks(HttpServletRequest req, HttpServletResponse res) {
		String admn_no = req.getParameter("admission_no");

		int sem = Integer.parseInt(req.getParameter("sem"));
		System.out.println("inside View mark in controller");
		ModelAndView m = addservice.displayStudentMarks(admn_no, sem);

		return m;

	}

}
