package com.campus.configure;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
@ComponentScan(basePackages = { "com"})
public class Configure {
	
	  @Bean
	  public InternalResourceViewResolver resolver() {
	  InternalResourceViewResolver v=new InternalResourceViewResolver();
	  v.setPrefix("/");
	  v.setSuffix(".jsp");
	  return v; }
	 

}
